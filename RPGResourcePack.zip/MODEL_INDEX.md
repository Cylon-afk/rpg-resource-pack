# RPG custom models — Mythic item → CMD → pack files

Single source of truth for **CustomModelData** on vanilla base items and the resource pack paths they resolve to. After changing any CMD or model, rebuild `RPGResourcePack.zip` and update `resource-pack-sha1` in `server.properties` (see `scripts/Build-RPGResourcePack.ps1` and `HOSTING_RESOURCE_PACK.md`).

## Weapons (`plugins/MythicMobs/items/RPGWeapons.yml`)

| Mythic item      | Base item       | CMD  | Item override / model                         | Texture(s)                          |
| ---------------- | --------------- | ---- | --------------------------------------------- | ----------------------------------- |
| DragonSlayer     | DIAMOND_SWORD   | 1001 | `models/item/diamond_sword.json` → `rpg/dragonslayer` | `textures/rpg/dragonslayer.png`   |
| ShadowBlade      | DIAMOND_SWORD   | 1002 | → `rpg/shadowblade`                         | `textures/rpg/shadowblade.png`      |
| WindPiercer      | BOW             | 1003 | `models/item/bow.json` → `rpg/windpiercer`  | `textures/rpg/windpiercer.png`      |
| TitanCrusher     | NETHERITE_AXE   | 1004 | `models/item/netherite_axe.json` → `rpg/titancrusher` | (see `netherite_axe.json`)        |
| ArchmageStaff    | BLAZE_ROD       | 1005 | `models/item/blaze_rod.json` → `rpg/archmagestaff` | `textures/rpg/archmagestaff.png` (placeholder; replace in art pass) |
| HeavyBallista    | CROSSBOW        | 1006 | `models/item/crossbow.json` → `rpg/heavyballista` | `textures/rpg/heavyballista.png` (placeholder) |

## Armor (`plugins/MythicMobs/items/RPGArmor.yml`)

Worn appearance uses `models/armor/{dragonscale,shadowassassin,paladin}.json` with `textures/rpg/*_layer1.png` / `*_layer2.png`. Inventory/hand icons use `models/item/<base>_<slot>.json` overrides below.

| Mythic item           | Base item           | CMD  | Item override → model                              | Notes                                      |
| --------------------- | ------------------- | ---- | -------------------------------------------------- | ------------------------------------------ |
| DragonScaleHelmet     | NETHERITE_HELMET    | 3001 | `netherite_helmet.json` → `item/netherite_helmet_dragonscale` | `rpg/dragonscale_helmet.png`               |
| DragonScaleChestplate | NETHERITE_CHESTPLATE| 3002 | `netherite_chestplate.json` → `item/netherite_chestplate_dragonscale` | Icon uses `rpg/dragonscale_layer1.png`     |
| DragonScaleLeggings   | NETHERITE_LEGGINGS  | 3003 | `netherite_leggings.json` → `item/netherite_leggings_dragonscale` | same                                       |
| DragonScaleBoots      | NETHERITE_BOOTS     | 3004 | `netherite_boots.json` → `item/netherite_boots_dragonscale` | same                                       |
| ShadowAssassinHood    | LEATHER_HELMET      | 3005 | `leather_helmet.json` → `item/leather_helmet_shadowassassin` | `rpg/shadowassassin_helmet*.png`           |
| ShadowAssassinTunic   | LEATHER_CHESTPLATE  | 3006 | `leather_chestplate.json` → `item/leather_chestplate_shadowassassin` | `rpg/shadowassassin_layer1/2.png`          |
| ShadowAssassinLeggings| LEATHER_LEGGINGS    | 3007 | `leather_leggings.json` → `item/leather_leggings_shadowassassin` | same                                       |
| ShadowAssassinBoots   | LEATHER_BOOTS       | 3008 | `leather_boots.json` → `item/leather_boots_shadowassassin` | same                                       |
| PaladinHelmet         | GOLDEN_HELMET       | 3009 | `golden_helmet.json` → `item/golden_helmet_paladin` | `rpg/paladin_helmet.png`                   |
| PaladinChestplate     | GOLDEN_CHESTPLATE   | 3010 | `golden_chestplate.json` → `item/golden_chestplate_paladin` | `rpg/paladin_layer1.png` (inventory icon)  |
| PaladinLeggings       | GOLDEN_LEGGINGS     | 3011 | `golden_leggings.json` → `item/golden_leggings_paladin` | same                                       |
| PaladinBoots          | GOLDEN_BOOTS        | 3012 | `golden_boots.json` → `item/golden_boots_paladin` | same                                       |

## Tools (`plugins/MythicMobs/items/RPGTools.yml`)

If present, document CMD and paths here when tools gain custom models.

## Art pass (optional follow-up)

- Replace **placeholder** staff/crossbow textures with final art; keep CMDs stable.
- Optional: per-slot **inventory-only** PNGs for Dragon Scale / Shadow / Paladin body slots instead of shared layer textures.

## In-game validation (1.21.11 client)

1. Upload the rebuilt `RPGResourcePack.zip` to the GitHub raw URL in `server.properties` and set `resource-pack-sha1` to the SHA-1 printed by `scripts/Build-RPGResourcePack.ps1` (must match the hosted file).
2. Join with `require-resource-pack=true`; reload assets with **F3+T** if testing locally.
3. Run `/mm items give` for each Mythic item in `RPGWeapons.yml`, `RPGArmor.yml`, and `RPGTools.yml`; confirm inventory icon, first-person hold (**F5**), and worn armor (armor stand or second player).
